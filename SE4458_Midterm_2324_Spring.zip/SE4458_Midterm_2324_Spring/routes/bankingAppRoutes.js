const express = require('express');
const router = express.Router();

router.get('/QueryUnpaidBills', async (req, res) => {
    try {
        const subscriberNo = req.query.subscriberNo;
        const query = { subscriberNo: subscriberNo, paid: false };
        const projection = { month: 1, billTotal: 1, _id: 0 };
        const unpaidBills = await db.collection('bills').find(query, projection).toArray();

        if (unpaidBills.length > 0) {
            const unpaidBillsByMonth = {};
            unpaidBills.forEach(bill => {
                if (!unpaidBillsByMonth[bill.month]) {
                    unpaidBillsByMonth[bill.month] = [];
                }
                unpaidBillsByMonth[bill.month].push(bill.billTotal);
            });

            res.json(unpaidBillsByMonth);
        } else {
            res.status(404).json({ message: 'Ödenmemiş fatura bulunamadı.' });
        }
    } catch (error) {
        console.error('Hata oluştu:', error);
        res.status(500).json({ message: 'Sunucu hatası, ödenmemiş faturalar alınamadı.' });
    }
});

module.exports = router;