const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

const secretKey = 'k:DU9f&dKW8Fka2cT54zvM2L$dR7VJ!';


router.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        const token = jwt.sign({ username }, secretKey, { expiresIn: '1h' });
        res.json({ token });
    } else {
        res.status(401).json({ message: 'Kullanıcı adı veya şifre hatalı' });
    }
});

router.get('/private', authenticateToken, (req, res) => {
    res.json({ message: 'Bu gizli veri sadece oturum açmış kullanıcılara gösterilir.' });
});

function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) return res.sendStatus(401);

    jwt.verify(token, secretKey, (err, user) => {
        if (err) return res.sendStatus(403); 
        req.user = user;
        next();
    });
}

module.exports = router;
