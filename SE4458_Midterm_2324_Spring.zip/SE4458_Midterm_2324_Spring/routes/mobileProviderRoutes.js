const express = require('express');
const router = express.Router();
const mobileProviderController = require('../controllers/mobileProviderController');

router.get("/get-QueryBill", mobileProviderController.queryBill, async (req,res) => {
    try {
        const bills = await Bill.find();
        res.status(200).json(bills)
    } catch (error) {
        res.status(400).json(error)
    }
});

router.put("/update-QueryBill", async (req,res) => {
    try {
        await Bill.findOneAndUpdate({ _id: req.body.billId}, req.body);
        res.status(200).json("Başarılı bir şekilde değiştirildi.")
    } catch (error) {
        res.status(400).json(error)
    }
});

router.delete("/delete-QueryBill", async (req,res) => {
    try {
        await Bill.findOneAndDelete({ _id: req.body.billId});
        res.status(200).json("Başarılı bir şekilde silindi.")
    } catch (error) {
        res.status(400).json(error)
    }
})

router.post("/add-QueryBill", async (req, res) => {
  try {
    const newBill = new Bill(req.body);
    await newBill.save();
    res.status(200).json("Başarılı bir şekilde eklendi.")
  } 
  catch (error) {
    res.status(400).json(error)
  }
});

router.get('/get-QueryBillDetailed', mobileProviderController.queryBillDetailed, async (req, res) => {
    try {
        const subscriberNo = req.query.subscriberNo;
        const month = req.query.month;

        const query = { subscriberNo: subscriberNo, month: month };
        const result = await db.collection('bills').findOne(query);

        if (result) {
            const response = {
                billTotal: result.billTotal,
                paidDetails: result.paidDetails
            };
            res.json(response);
        } else {
            res.status(404).json({ message: 'Belirtilen abone numarası ve ay için fatura bulunamadı.' });
        }
    } catch (error) {
        console.error('Hata oluştu:', error);
        res.status(500).json({ message: 'Sunucu hatası, fatura detayları alınamadı.' });
    }
});

module.exports = router;
