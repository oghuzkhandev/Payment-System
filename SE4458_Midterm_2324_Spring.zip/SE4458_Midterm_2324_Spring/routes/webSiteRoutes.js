const express = require('express');
const router = express.Router();
const webSiteController = require('../controllers/webSiteController');

router.post('/payBill', webSiteController.payBill, async (req, res) => {
    try {
        const subscriberNo = req.body.subscriberNo;
        const month = req.body.month;

        const filter = { subscriberNo: subscriberNo, month: month };
        const update = { $set: { paid: true } };
        const result = await db.collection('bills').updateOne(filter, update);

        if (result.modifiedCount > 0) {
            res.json({ status: 'Successful', message: 'Fatura başarıyla ödendi.' });
        } else {
            res.status(404).json({ status: 'Error', message: 'Belirtilen abone numarası ve ay için fatura bulunamadı veya zaten ödenmiş.' });
        }

    } catch (error) {
        res.status(500).json({ status: 'Error', message: 'Sunucu hatası, fatura ödenemedi.' });
    }
});

router.post('/adminAddBill', webSiteController.adminAddBill);

module.exports = router;
