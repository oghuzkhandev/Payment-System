const mongoose = require('mongoose');

const BillDetailSchema = new mongoose.Schema({
  description: {
    type: String,
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
});

const BillDetail = mongoose.model('BillDetail', BillDetailSchema);

module.exports = BillDetail;