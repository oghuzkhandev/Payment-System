const Bill = require('../models/Bill');

exports.queryBill = async (req, res) => {
    try {
        const { subscriberNo } = req.query;
        const bills = await Bill.find({ subscriberNo });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};