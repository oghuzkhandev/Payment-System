const Bill = require('../models/Bill');

exports.payBill = async (req, res) => {
    try {
        const { subscriberNo, month } = req.query;
        const bills = await Bill.find({ subscriberNo, month });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.adminAddBill = async (req, res) => {
    try {
        // Admin add bill logic
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};