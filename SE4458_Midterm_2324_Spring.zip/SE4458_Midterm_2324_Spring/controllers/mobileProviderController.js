const Bill = require('../models/Bill');

exports.queryBill = async (req, res) => {
    try {
        const { subscriberNo, month } = req.query;
        const bills = await Bill.find({ subscriberNo, month });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.queryBillDetailed = async (req, res) => {
    try {
        const { subscriberNo, month } = req.query;
        const detailedBills = await Bill.find({ subscriberNo, month }).populate('details');
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};