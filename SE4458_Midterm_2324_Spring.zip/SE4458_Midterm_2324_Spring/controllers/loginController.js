const jwt = require('jsonwebtoken');
const secretKey = 'k:DU9f&dKW8Fka2cT54zvM2L$dR7VJ!';

exports.login = (req, res) => {
    const username = req.body.username;
    const user = { username: username };
    const accessToken = jwt.sign(user, secretKey);
    console.log("Token alındı:", accessToken);
    res.json({ accessToken: accessToken });
};